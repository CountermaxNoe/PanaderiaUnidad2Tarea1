﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progaram3unidad2
{
    public enum Carreras { Sistemas, Mecatronica, Industrial}
    public class Alumnos
    {
        public string NoControl { get; set; } = null!;
        public string Nombre { get; set; } = null!;
        public Carreras Carrera { get; set; }
    }
}
