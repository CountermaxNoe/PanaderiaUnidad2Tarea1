﻿
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Progaram3unidad2
{
    public class Grupo: INotifyPropertyChanged
    {
        public ObservableCollection<Alumnos> Alumnos { get; set; } = new();
        public ICommand AgregarCommand { get; set; }
        public ICommand EliminarCommand { get; set; }
        public Alumnos Alumno { get; set; }=new();

        public Grupo()
        {
            Cargar();
            AgregarCommand = new RelayCommand<Alumnos>(Agregar);
            EliminarCommand = new RelayCommand(Eliminar);
        }
        public void Agregar(Alumnos? Alumno)
        {
            if (Alumno != null)
            {
                //validacion
                var otro = new Alumnos //cre un clon del alumno para guardar los datos y que no se repita
                {
                    Carrera = Alumno.Carrera,
                    NoControl = Alumno.NoControl,
                    Nombre = Alumno.Nombre,
                };
                Alumnos.Add(otro);
                Guardar();
            }
        }
        public void Eliminar()
        {
            if (Alumno != null)
            {
                Alumnos.Remove(Alumno);
                Guardar();
            }
        }
        public void Cargar()
        {
            if (File.Exists("alumnos.json"))
            {
                string json = File.ReadAllText("alumnos.json");
                var datos = JsonSerializer.Deserialize<ObservableCollection<Alumnos>>(json);
                if (datos != null)
                {
                    Alumnos= datos;
                    //agregar a lo que ya tenga
                    //foreach (var a in datos)
                    //{
                        //Alumnos.Add(a);
                    //}
                }
            }
        }
        public void Guardar()
        {
            var json = JsonSerializer.Serialize(Alumnos);
            File.WriteAllText("alumnos.json", json);
        }
        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
